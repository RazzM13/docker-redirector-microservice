const express = require('express');
const MongoClient = require('mongodb').MongoClient;


const handler = async (req, res, next) => {
    const app = req.app;
    const dbc = app.db.collection('url_registry');

    const redirectID = req.params.id;
    const redirectURL = req.query.url;


    // validate pathParameters
    if (!redirectID) {
        res.body = {
            'error': 'Redirection ID not specified!'
        };
        return next();
    }

    const item = await dbc.findOne({
        'id': redirectID
    });

    switch (req.method) {
        case 'GET':
            if (!!item) {
                res.set('Location', item['url']);
                res.set(['Referrer-Policy'], 'no-referrer');
                res.statusCode = 302;
            } else {
                res.body = {
                    'error': 'A redirection has not been found for the specified ID!'
                };
                res.statusCode = 404;
                return next();
            }
            break;

        case 'POST':
            if (!item && !!redirectURL) {
                return dbc.insertOne({
                    'id': redirectID,
                    'url': redirectURL
                })
                    .then(() => {
                        res.statusCode = 201;
                    })
                    .catch((e) => {
                        console.error(e);
                        res.statusCode = 400;
                        return next();
                    });
            } else {
                if (!!item) {
                    res.statusCode = 409;
                    res.body = {
                        'error': 'A redirection has already been registered for the specified ID!'
                    };
                    return next();
                }

                if (!redirectURL) {
                    res.statusCode = 400;
                    res.body = {
                        'error': 'Redirection target URL not specified!'
                    };
                    return next();
                }
            }
            break;

        case 'PUT':
            if (!!item && !!redirectURL) {
                return dbc.updateOne({
                    'id': redirectID,
                    '$set': {
                        'url': redirectURL
                    }
                })
                    .then(() => {
                        res.statusCode = 200;
                    })
                    .catch((e) => {
                        console.error(e);
                        res.statusCode = 400;
                        return next();
                    });
            } else {
                if (!item) {
                    res.statusCode = 404;
                    res.body = {
                        'error': 'No redirection registered for the specified ID!'
                    };
                    return next();
                }

                if (!redirectURL) {
                    res.statusCode = 400;
                    res.body = {
                        'error': 'Redirection target URL not specified!'
                    };
                    return next();
                }
            }
            break;

        case 'DELETE':
            if (!!item) {
                return dbc.deleteOne({
                    'id': redirectID
                })
                    .then(() => {
                        res.statusCode = 200;
                    })
                    .catch((e) => {
                        console.error(e);
                        res.statusCode = 400;
                        return next();
                    });
            } else {
                if (!item) {
                    res.statusCode = 404;
                    res.body = {
                        'error': 'No redirection registered for the specified ID!'
                    };
                    return next();
                }
            }
            break;

        default:
            res.body = 'Invalid HTTP method!';
            res.statusCode = 400;
            return next();
    }

    res.send();
};


const mongoClient = new MongoClient('mongodb://database');
mongoClient.connect()
    .then(() => {
        const app = express();
        app.db = mongoClient.db('redirector');
        app.all('/r/:id*?', handler);
        app.listen(8000);
    })
    .catch((err) => {
        console.error('Unable to connect to DB!', err);
        return mongoClient.close();
    });
